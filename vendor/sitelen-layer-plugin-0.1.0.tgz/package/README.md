# sitelen-layer-plugin

A **site-owner plugin** for pages that already contain toki pona content.

It adds display layers for the same text:

- `latin`
- `sitelen-pona` (font-based, recommended `nasin-sitelen-pu`)
- `sitelen-emoji` (mapping-based)

## Quick Start

```ts
import { createSitelenLayerPlugin } from 'sitelen-layer-plugin';
import 'sitelen-layer-plugin/styles.css';

const plugin = createSitelenLayerPlugin({
  container: '#tok-content',
  threshold: 0.7,
  requireDominantTokiPona: true
});

plugin.init();
```

## Copy-Paste Integrations

### 1) Static landing page

```ts
import { createSitelenLayerPlugin } from 'sitelen-layer-plugin';
import 'sitelen-layer-plugin/styles.css';

createSitelenLayerPlugin({
  container: '#landing-toki-pona',
  defaultLayer: 'latin',
  showToggle: true
}).init();
```

### 2) SPA-like page (route changes)

```ts
import { createSitelenLayerPlugin } from 'sitelen-layer-plugin';
import 'sitelen-layer-plugin/styles.css';

const plugin = createSitelenLayerPlugin({
  container: '#app-main',
  mutationObserver: {
    enabled: true,
    incremental: true,
    debounceMs: 140,
    observeAttributes: false
  },
  spaNavigation: {
    enabled: true,
    patchHistory: true,
    refreshDelayMs: 80
  }
});

plugin.init();
```

### 3) Explicit scope with `data-sitelen-layer-scope`

```html
<main id="content">
  <section data-sitelen-layer-scope>
    <!-- only this subtree is analyzed/transformed -->
  </section>
</main>
```

```ts
createSitelenLayerPlugin({ container: '#content' }).init();
```

## Profiles Example

```ts
import { createSitelenLayerPluginFromProfiles } from 'sitelen-layer-plugin';
import 'sitelen-layer-plugin/styles.css';

const plugin = createSitelenLayerPluginFromProfiles(
  [
    {
      id: 'tok-locale',
      priority: 20,
      match: { pathnamePrefix: '/tok/' },
      config: {
        container: '#tok-content',
        defaultLayer: 'sitelen-emoji',
        showToggle: true
      }
    },
    {
      id: 'en-locale',
      priority: 10,
      match: { pathnamePrefix: '/en/' },
      config: {
        container: '#en-content',
        showToggle: false
      }
    }
  ],
  {
    baseConfig: {
      threshold: 0.7,
      onProfileMatch: (id) => console.log('matched profile:', id)
    }
  }
);

plugin.init();
```

Matching priority: highest `priority` wins among matched profiles.

## Example: Real Project Integration

Project: **toki-free-kit (ABVX)**

- Live TP locale: <https://toki-free.abvx.xyz/tp>
- Repo: <https://github.com/markoblogo/toki-free-kit>

What this integration demonstrates:

- toki pona-dominant eligibility flow
- layer switching (`latin` / `sitelen-pona` / `sitelen-emoji`)
- profile-based activation for `/tp`
- debug diagnostics during integration and tuning

Important: `sitelen-layer-plugin` is a **display-layer plugin** for existing toki pona content, not a machine translation system.

## Tested Integrations

- [toki-free-kit](https://github.com/markoblogo/toki-free-kit) — `/tp` locale showcase with profile-based activation.

## Sitelen Pona Font Config Example

```ts
createSitelenLayerPlugin({
  container: '#tok-content',
  sitelenPona: {
    enabled: true,
    fontFamily: "'nasin-sitelen-pu', 'Noto Sans', sans-serif",
    fontCssUrl: 'https://example.com/fonts/nasin-sitelen-pu.css',
    className: 'my-sitelen-pona-layer',
    renderStrategy: 'font-only'
  }
}).init();
```

## What This Does NOT Do

- Does **not** translate from other languages into toki pona.
- Does **not** process text in images / OCR.
- Is **not** a browser extension for arbitrary third-party sites.
- Does **not** guarantee perfect typography on every site without CSS tuning.

## Troubleshooting Sitelen Pona Font

Common issues:

- `fontCssUrl` blocked by CSP.
- Font file loads but CSS specificity prevents application.
- Font loaded, but custom site CSS overrides plugin class.
- Font readiness is false in diagnostics/overlay.

Checklist:

1. Verify font URL is allowed by your CSP.
2. Check network panel for font/CSS responses.
3. Confirm diagnostics shows `sitelenPonaFontReady: true`.
4. Apply stronger CSS selector with custom class.

Example with stronger specificity:

```css
/* plugin config: sitelenPona.className = "my-sitelen-pona-layer" */
#tok-content.my-sitelen-pona-layer,
#tok-content.my-sitelen-pona-layer * {
  font-family: 'nasin-sitelen-pu', 'Noto Sans', sans-serif !important;
  font-variant-ligatures: common-ligatures discretionary-ligatures;
}
```

## SPA / Observer Recommendations

- Use `mutationObserver.incremental=true` for frequent append/replace UI updates.
- Keep `observeAttributes=false` unless attribute changes materially alter text eligibility.
- Prefer explicit `refresh()` on known route hooks for large route transitions.
- Keep observer settings moderate by default; avoid aggressive full rescans.

## Public API

- `createSitelenLayerPlugin(config)`
- `createSitelenLayerPluginFromProfiles(profiles, options)`
- `plugin.init()`
- `plugin.refresh()`
- `plugin.destroy()`
- `plugin.getDiagnostics()`
- `plugin.showDiagnosticsOverlay()` / `plugin.hideDiagnosticsOverlay()`

## Package Usage

```ts
import { createSitelenLayerPlugin } from 'sitelen-layer-plugin';
import { createSitelenLayerPluginFromProfiles } from 'sitelen-layer-plugin';
import 'sitelen-layer-plugin/styles.css';
```

## Key Config (selected)

- `threshold` (default `0.7`)
- `requireDominantTokiPona` (default `true`)
- `mutationObserver.enabled` / `mutationObserver.incremental`
- `spaNavigation.enabled`
- `sitelenPona.fontFamily`, `sitelenPona.fontCssUrl`, `sitelenPona.className`
- `onDiagnostics`, `onLayerChange`, `onProfileMatch`

## Diagnostics

`getDiagnostics()` includes:

- detection: `score`, `threshold`, `eligible`, `totalTokens`, `recognizedTokens`
- layer state: `activeLayer`, `modeSource`, `availableLayers`
- profile state: `profileId`, `matchedProfileId`, `matchedProfileReason`
- observer state: `observerStats`
- timing: `lastUpdatedAt`

## QA And Tests

- QA fixtures: `/qa/index.html`
- Manual checklist: `qa/README.md`
- Run automated tests:

```bash
npm run test:run
```

## Development

```bash
npm install
npm run dev
npm run build
```
